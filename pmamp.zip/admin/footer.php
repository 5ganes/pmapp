<table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="50" class="lightbg footer">Copyright &copy; <?php echo date('Y'); ?>. All Rights Reserved.</td>
  </tr>
</table>
